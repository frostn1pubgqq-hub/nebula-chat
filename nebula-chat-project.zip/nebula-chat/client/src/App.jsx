import React, { useEffect, useMemo, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { Activity, Plus, Compass, Headphones, Mic, MicOff, Settings, Hash, Volume2, ChevronDown, ChevronRight, Send, LogOut, Menu, X, Users, Shield, Video, PhoneOff, MessageCircle, Search, Smile, Paperclip, Bell, CircleHelp, Copy, Check } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const SOCKET = import.meta.env.VITE_SOCKET_URL || API;
const request = async (path, token, options={}) => {
  const res = await fetch(`${API}${path}`, { ...options, headers:{'Content-Type':'application/json', ...(token?{Authorization:`Bearer ${token}`} : {}), ...(options.headers||{})}});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};
const initials = s => (s||'?').slice(0,2).toUpperCase();
const time = d => new Date(d).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
const palette = ['#5965f2','#da6a9b','#41a38a','#e4a84b','#9a78d4'];

function Auth({onAuth}) {
  const [mode,setMode]=useState('login'), [username,setUsername]=useState(''), [password,setPassword]=useState(''), [error,setError]=useState(''), [busy,setBusy]=useState(false);
  async function submit(e){e.preventDefault();setBusy(true);setError('');try{const d=await request(`/api/auth/${mode}`,null,{method:'POST',body:JSON.stringify({username,password})});onAuth(d);}catch(e){setError(e.message)}finally{setBusy(false)}}
  return <div className="auth-screen"><div className="auth-card"><div className="brand-mark"><Activity size={25}/></div><h1>{mode==='login'?'С возвращением!':'Создать аккаунт'}</h1><p className="muted">{mode==='login'?'Рады снова тебя видеть.':'Твоё сообщество начинается здесь.'}</p><form onSubmit={submit}><label>ИМЯ ПОЛЬЗОВАТЕЛЯ</label><input value={username} onChange={e=>setUsername(e.target.value)} minLength="3" maxLength="24" required placeholder="например, starlord"/><label>ПАРОЛЬ</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength="8" required placeholder="Не менее 8 символов"/>{error&&<div className="error">{error}</div>}<button className="primary full" disabled={busy}>{busy?'Подожди…':mode==='login'?'Войти':'Зарегистрироваться'}</button></form><p className="auth-switch">{mode==='login'?'Впервые здесь?':'Уже есть аккаунт?'} <button className="text-button" onClick={()=>{setMode(mode==='login'?'register':'login');setError('')}}>{mode==='login'?'Создать аккаунт':'Войти'}</button></p><div className="auth-foot">NEBULA COMMUNITY • YOUR SPACE, YOUR PEOPLE</div></div></div>;
}

export default function App(){
  const [session,setSession]=useState(()=>{try{return JSON.parse(localStorage.getItem('nebula-session'))}catch{return null}});
  const [me,setMe]=useState(null), [servers,setServers]=useState([]), [activeServer,setActiveServer]=useState(null), [activeChannel,setActiveChannel]=useState(null);
  const [messages,setMessages]=useState([]), [draft,setDraft]=useState(''), [socket,setSocket]=useState(null), [users,setUsers]=useState([]);
  const [view,setView]=useState('chat'), [mobilePanel,setMobilePanel]=useState(false), [showCreate,setShowCreate]=useState(''), [newName,setNewName]=useState(''), [error,setError]=useState('');
  const [dmUser,setDmUser]=useState(null), [dmMessages,setDmMessages]=useState([]), [callRoom,setCallRoom]=useState(null), [muted,setMuted]=useState(false), [deafened,setDeafened]=useState(false);
  const [callState,setCallState]=useState(''), [roleView,setRoleView]=useState(false), [inviteCopied,setInviteCopied]=useState(false);
  const bottomRef=useRef(null), streamRef=useRef(null), peersRef=useRef({}), socketRef=useRef(null);
  useEffect(()=>{if(!session)return; localStorage.setItem('nebula-session',JSON.stringify(session)); request('/api/me',session.token).then(setMe).catch(()=>{localStorage.removeItem('nebula-session');setSession(null)}); request('/api/servers',session.token).then(s=>{setServers(s);if(s[0]){setActiveServer(s[0]);setActiveChannel(s[0].channels.find(c=>c.type==='text')||s[0].channels[0]||null)}}).catch(e=>setError(e.message)); request('/api/users',session.token).then(setUsers).catch(()=>{}); const s=io(SOCKET,{auth:{token:session.token}});socketRef.current=s;setSocket(s);return()=>{s.disconnect();streamRef.current?.getTracks().forEach(t=>t.stop())}},[session?.token]);
  useEffect(()=>{if(!socket||!activeChannel||activeChannel.type!=='text')return;socket.emit('channel:join',{channelId:activeChannel.id});request(`/api/channels/${activeChannel.id}/messages`,session.token).then(setMessages).catch(e=>setError(e.message));const handler=m=>{if(m.channelId===activeChannel.id)setMessages(old=>old.some(x=>x.id===m.id)?old:[...old,m])};socket.on('message:new',handler);return()=>socket.off('message:new',handler)},[socket,activeChannel?.id,session?.token]);
  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:'smooth'})},[messages]);
  useEffect(()=>{if(!socket)return;const handler=m=>{if(dmUser&&(m.senderId===dmUser.id||m.receiverId===dmUser.id))setDmMessages(old=>[...old,m])};socket.on('dm:new',handler);return()=>socket.off('dm:new',handler)},[socket,dmUser?.id]);
  useEffect(()=>{
    if(!socket)return;
    const makePeer = peerId => {
      if(peersRef.current[peerId]) return peersRef.current[peerId];
      const pc = new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
      streamRef.current?.getTracks().forEach(track=>pc.addTrack(track,streamRef.current));
      pc.onicecandidate = e => { if(e.candidate && callRoom) socket.emit('call:signal',{roomId:callRoom,targetId:peerId,signal:{type:'ice',candidate:e.candidate}}); };
      pc.ontrack = e => {
        let audio = document.getElementById(`remote-audio-${peerId}`);
        if(!audio){audio=document.createElement('audio');audio.id=`remote-audio-${peerId}`;audio.autoplay=true;audio.playsInline=true;audio.style.display='none';document.body.appendChild(audio);}
        audio.srcObject=e.streams[0];
        audio.play().catch(()=>{});
      };
      pc.onconnectionstatechange=()=>{if(['failed','closed','disconnected'].includes(pc.connectionState)){pc.close();delete peersRef.current[peerId];}};
      peersRef.current[peerId]=pc;
      return pc;
    };
    const peerJoined = async ({peerId}) => {
      try { const pc=makePeer(peerId); const offer=await pc.createOffer(); await pc.setLocalDescription(offer); socket.emit('call:signal',{roomId:callRoom,targetId:peerId,signal:{type:'description',description:pc.localDescription}}); } catch(e){console.warn('Call offer failed',e);}
    };
    const signal = async ({from,signal:packet,roomId}) => {
      if(!callRoom || roomId!==callRoom || !packet)return;
      try {
        const pc=makePeer(from);
        if(packet.type==='description'){
          await pc.setRemoteDescription(packet.description);
          if(packet.description.type==='offer'){const answer=await pc.createAnswer();await pc.setLocalDescription(answer);socket.emit('call:signal',{roomId,targetId:from,signal:{type:'description',description:pc.localDescription}});}
        } else if(packet.type==='ice' && packet.candidate) {
          try{await pc.addIceCandidate(packet.candidate)}catch(e){console.warn('ICE candidate skipped',e);}
        }
      } catch(e){console.warn('Call signaling failed',e);}
    };
    const peerLeft=({peerId})=>{peersRef.current[peerId]?.close();delete peersRef.current[peerId];const audio=document.getElementById(`remote-audio-${peerId}`);audio?.remove();};
    socket.on('call:peer-joined',peerJoined);socket.on('call:signal',signal);socket.on('call:peer-left',peerLeft);
    return()=>{socket.off('call:peer-joined',peerJoined);socket.off('call:signal',signal);socket.off('call:peer-left',peerLeft)};
  },[socket,callRoom]);
  async function refreshServers(selectId){const s=await request('/api/servers',session.token);setServers(s);const picked=s.find(x=>x.id===selectId)||s.find(x=>x.id===activeServer?.id)||s[0];setActiveServer(picked||null);if(picked)setActiveChannel(picked.channels.find(c=>c.type==='text')||picked.channels[0]||null)}
  async function createServer(e){e.preventDefault();try{const s=await request('/api/servers',session.token,{method:'POST',body:JSON.stringify({name:newName})});setServers(old=>[...old,s]);setActiveServer(s);setActiveChannel(s.channels[0]);setShowCreate('');setNewName('')}catch(e){setError(e.message)}}
  async function createChannel(e){e.preventDefault();try{const c=await request(`/api/servers/${activeServer.id}/channels`,session.token,{method:'POST',body:JSON.stringify({name:newName,type:showCreate==='voice'?'voice':'text'})});const updated={...activeServer,channels:[...activeServer.channels,c]};setServers(old=>old.map(s=>s.id===updated.id?updated:s));setActiveServer(updated);setActiveChannel(c);setShowCreate('');setNewName('')}catch(e){setError(e.message)}}
  function sendMessage(e){e?.preventDefault();const content=draft.trim();if(!content)return;if(dmUser){request('/api/dm',session.token,{method:'POST',body:JSON.stringify({receiverId:dmUser.id,content})}).then(m=>setDmMessages(old=>[...old,m])).catch(e=>setError(e.message));setDraft('');return}if(activeChannel?.type==='text'){socket?.emit('message:send',{channelId:activeChannel.id,content});setDraft('')}}
  async function openDM(user){setDmUser(user);setView('dm');setMobilePanel(false);try{setDmMessages(await request(`/api/dm/${user.id}`,session.token))}catch(e){setError(e.message)}}
  async function startCall(channel){try{const stream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});streamRef.current=stream;const roomId=channel.id;setCallRoom(roomId);setCallState('Ты подключён к голосовому каналу');socket.emit('call:join',{roomId});setView('call')}catch{setError('Не удалось получить доступ к микрофону. Проверь разрешения браузера.')}}
  function leaveCall(){if(callRoom)socket?.emit('call:leave',{roomId:callRoom});streamRef.current?.getTracks().forEach(t=>t.stop());streamRef.current=null;Object.values(peersRef.current).forEach(p=>p.close());peersRef.current={};setCallRoom(null);setCallState('');setView('chat')}
  function logout(){localStorage.removeItem('nebula-session');socket?.disconnect();setSession(null);setMe(null);setServers([])}
  if(!session||!me)return <Auth onAuth={d=>{localStorage.setItem('nebula-session',JSON.stringify(d));setSession(d);setMe(d.user)}}/>;
  const channel=activeChannel, isDM=view==='dm';
  const serverName=activeServer?.name||'Твои сообщества';
  return <div className="app-shell">
    <aside className="server-rail">
      <button className="rail-logo selected" title="Главная" onClick={()=>{setView('chat');setDmUser(null)}}><Activity/></button><div className="rail-sep"/>
      {servers.map((s,i)=><button key={s.id} className={`server-icon ${activeServer?.id===s.id&&!isDM?'chosen':''}`} title={s.name} style={{'--server-color':palette[i%palette.length]}} onClick={()=>{setActiveServer(s);setActiveChannel(s.channels.find(c=>c.type==='text')||s.channels[0]||null);setDmUser(null);setView('chat')}}>{initials(s.name)}</button>)}
      <button className="rail-add" title="Создать сервер" onClick={()=>{setShowCreate('server');setNewName('')}}><Plus/></button>
      <button className="rail-explore" title="Обзор"><Compass/></button>
      <div className="rail-bottom"><button onClick={()=>setView('settings')} title="Настройки"><Settings/></button></div>
    </aside>
    <aside className={`channel-sidebar ${mobilePanel?'mobile-open':''}`}>
      <div className="sidebar-top"><div className="sidebar-brand"><span className="brand-mini"><Activity size={17}/></span><span>Nebula</span></div><button className="icon-btn" onClick={()=>setMobilePanel(false)}><X className="mobile-only"/></button></div>
      <button className={`home-row ${isDM?'active':''}`} onClick={()=>{setView('dmhome');setDmUser(null)}}><MessageCircle size={18}/> Личные сообщения</button>
      <div className="section-label">ВАШИ СООБЩЕСТВА <button onClick={()=>{setShowCreate('server');setNewName('')}}><Plus size={15}/></button></div>
      <div className="server-title"><span>{serverName}</span><ChevronDown size={15}/><button onClick={()=>{setShowCreate('channel');setNewName('')}} title="Создать канал"><Plus size={15}/></button></div>
      {activeServer?.channels?.map(c=><button key={c.id} className={`channel-row ${channel?.id===c.id&&!isDM?'active':''}`} onClick={()=>{if(c.type==='voice'){startCall(c);return}setActiveChannel(c);setView('chat');setDmUser(null);setMobilePanel(false)}}>{c.type==='voice'?<Volume2 size={17}/>:<Hash size={17}/>}<span>{c.name}</span>{c.type==='voice'&&<span className="voice-dot"/>}</button>)}
      {!activeServer&&<div className="empty-sidebar">Создай сервер, чтобы начать общаться.</div>}
      <div className="section-label people-label">БЫСТРЫЕ СООБЩЕНИЯ <button onClick={()=>setView('dmhome')}><Plus size={15}/></button></div>
      {users.slice(0,8).map((u,i)=><button key={u.id} className={`person-row ${dmUser?.id===u.id?'active':''}`} onClick={()=>openDM(u)}><span className="avatar small" style={{'--avatar-color':palette[i%palette.length]}}>{initials(u.username)}<i className={u.status==='online'?'online':''}/></span><span>{u.username}</span></button>)}
      <div className="user-panel"><div className="avatar" style={{'--avatar-color':'#5965f2'}}>{initials(me.username)}</div><div className="user-meta"><b>{me.username}</b><span>В сети</span></div><button className="icon-btn" onClick={()=>setMuted(!muted)} title="Микрофон">{muted?<MicOff size={17}/>:<Mic size={17}/>}</button><button className="icon-btn" onClick={()=>setDeafened(!deafened)} title="Звук">{deafened?<PhoneOff size={17}/>:<Headphones size={17}/>}</button><button className="icon-btn" onClick={logout} title="Выйти"><LogOut size={16}/></button></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="icon-btn mobile-only" onClick={()=>setMobilePanel(true)}><Menu/></button>{isDM?<><MessageCircle size={19}/><b>{dmUser?.username||'Личные сообщения'}</b></>:view==='settings'?<><Settings size={19}/><b>Настройки</b></>:view==='dmhome'?<><MessageCircle size={19}/><b>Личные сообщения</b></>:<><Hash size={19}/><b>{channel?.name||'Выбери канал'}</b></>}<div className="topbar-spacer"/><button className="icon-btn" title="Участники" onClick={()=>setRoleView(!roleView)}><Users size={18}/></button><button className="icon-btn" title="Уведомления"><Bell size={18}/></button><button className="icon-btn" title="Помощь"><CircleHelp size={18}/></button></header>
      {error&&<div className="error-banner">{error}<button onClick={()=>setError('')}><X size={15}/></button></div>}
      {view==='settings'?<div className="welcome-screen"><Settings size={42}/><h2>Настройки профиля</h2><p>Вы вошли как <b>{me.username}</b>.</p><button className="secondary" onClick={logout}>Выйти из аккаунта</button></div>:
      view==='dmhome'?<div className="dm-home"><div className="dm-home-main"><div className="dm-hero-icon"><MessageCircle size={34}/></div><h2>Кто на связи?</h2><p>Выбери пользователя слева, чтобы начать личную переписку.</p><div className="user-grid">{users.slice(0,12).map((u,i)=><button className="user-card" key={u.id} onClick={()=>openDM(u)}><span className="avatar large" style={{'--avatar-color':palette[i%palette.length]}}>{initials(u.username)}</span><b>{u.username}</b><small>{u.status||'online'}</small></button>)}</div></div></div>:
      view==='call'?<div className="call-screen"><div className="call-orb"><Volume2 size={48}/></div><h2>Голосовой канал</h2><p>{callState}</p><p className="muted">Разреши доступ к микрофону в браузере. Для видеозвонков и связи между сетями потребуется расширить WebRTC/TURN-конфигурацию.</p><button className="danger" onClick={leaveCall}><PhoneOff size={17}/> Завершить звонок</button></div>:
      <><div className="chat-scroll">{isDM?dmMessages.map(m=><Message key={m.id} message={m} me={me}/>):messages.map(m=><Message key={m.id} message={m} me={me}/>)}<div ref={bottomRef}/>{!isDM&&!messages.length&&<div className="welcome-inline"><div className="welcome-hash"><Hash size={36}/></div><h2>Добро пожаловать в #{channel?.name||'канал'}!</h2><p>Это начало канала. Отправь первое сообщение, чтобы разговор пошёл.</p></div>}{isDM&&!dmMessages.length&&<div className="welcome-inline"><div className="welcome-hash"><MessageCircle size={32}/></div><h2>Начни разговор с {dmUser?.username}</h2><p>Отправь первое сообщение — здесь появится ваша переписка.</p></div>}</div>
      <form className="composer" onSubmit={sendMessage}><button type="button" className="composer-tool" title="Вложения (скоро)"><Plus size={21}/></button><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder={isDM?`Написать ${dmUser?.username||'пользователю'}…`:channel?`Написать в #${channel.name}`:'Сначала выбери канал'} disabled={!isDM&&(!channel||channel.type!=='text')}/><button type="button" className="composer-tool" title="Эмодзи"><Smile size={20}/></button><button className="send-btn" disabled={!draft.trim()}><Send size={18}/></button></form></>}
    </main>
    {roleView&&<aside className="member-sidebar"><div className="member-head">УЧАСТНИКИ — {activeServer?.members?.length||0}</div>{(activeServer?.members||[]).map((u,i)=><div className="member-row" key={u.id}><span className="avatar small" style={{'--avatar-color':palette[i%palette.length]}}>{initials(u.username)}</span><span>{u.username}</span>{u.roleName==='Admin'&&<Shield size={14} className="gold"/>}</div>)}{!activeServer&&<p className="muted">Выбери сервер</p>}</aside>}
    <footer className="mobile-nav"><button onClick={()=>setMobilePanel(true)}><Compass size={20}/><span>Серверы</span></button><button onClick={()=>{setView('dmhome');setDmUser(null)}}><MessageCircle size={20}/><span>Сообщения</span></button><button onClick={()=>setView('settings')}><Settings size={20}/><span>Профиль</span></button></footer>
    {showCreate&&<div className="modal-backdrop" onClick={()=>setShowCreate('')}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowCreate('')}><X size={18}/></button><h2>{showCreate==='server'?'Создать сообщество':'Создать канал'}</h2><p className="muted">{showCreate==='server'?'Собери друзей в одном месте.':'Дай каналу понятное название.'}</p><form onSubmit={showCreate==='server'?createServer:createChannel}><label>{showCreate==='server'?'НАЗВАНИЕ СООБЩЕСТВА':'НАЗВАНИЕ КАНАЛА'}</label><input autoFocus value={newName} onChange={e=>setNewName(e.target.value)} required maxLength={48} placeholder={showCreate==='server'?'Моя тусовка':'новый-канал'}/>{showCreate!=='server'&&<p className="muted">Тип: {showCreate==='voice'?'голосовой':'текстовый'} (создавай через кнопки + рядом с разделом)</p>}<button className="primary full">Создать</button></form></div></div>}
  </div>;
}
function Message({message,me}){const name=message.user?.username||message.sender?.username||'Пользователь';return <article className="message"><div className="avatar message-avatar" style={{'--avatar-color':palette[(name.charCodeAt(0)||0)%palette.length]}}>{initials(name)}</div><div className="message-body"><div className="message-meta"><b>{name}</b><time>{time(message.createdAt)}</time></div><div className="message-content">{message.content}</div></div></article>}
