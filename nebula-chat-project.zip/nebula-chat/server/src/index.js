import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import http from 'node:http';
import { Server as SocketServer } from 'socket.io';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const app = express();
const server = http.createServer(app);
const io = new SocketServer(server, {
  cors: { origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', methods: ['GET','POST'] }
});
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) console.warn('WARNING: Set JWT_SECRET in .env before deployment.');

function tokenFor(user) {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET || 'dev-only-change-me', { expiresIn: '7d' });
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, JWT_SECRET || 'dev-only-change-me'); next(); }
  catch { res.status(401).json({ error: 'Sign in required' }); }
}
const safeUser = u => ({ id: u.id, username: u.username, avatar: u.avatar, status: u.status });

app.get('/api/health', (_req,res) => res.json({ ok: true }));
app.post('/api/auth/register', async (req,res) => {
  try {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({error:'Username must be 3–24 letters, numbers or underscores.'});
    if (password.length < 8) return res.status(400).json({error:'Password must contain at least 8 characters.'});
    const exists = await prisma.user.findUnique({where:{username}});
    if (exists) return res.status(409).json({error:'Username already taken.'});
    const user = await prisma.user.create({data:{username,passwordHash:await bcrypt.hash(password,12)}});
    res.json({token:tokenFor(user),user:safeUser(user)});
  } catch { res.status(500).json({error:'Could not create account.'}); }
});
app.post('/api/auth/login', async (req,res) => {
  const user = await prisma.user.findUnique({where:{username:String(req.body.username || '').trim()}});
  if (!user || !await bcrypt.compare(String(req.body.password || ''), user.passwordHash)) return res.status(401).json({error:'Incorrect username or password.'});
  res.json({token:tokenFor(user),user:safeUser(user)});
});
app.get('/api/me', auth, async (req,res) => {
  const user = await prisma.user.findUnique({where:{id:req.user.id}});
  if (!user) return res.status(404).json({error:'User not found'});
  res.json(safeUser(user));
});
app.get('/api/users', auth, async (req,res) => {
  const users = await prisma.user.findMany({where:{id:{not:req.user.id}},select:{id:true,username:true,status:true,avatar:true},take:100});
  res.json(users);
});
app.get('/api/servers', auth, async (req,res) => {
  const memberships = await prisma.membership.findMany({where:{userId:req.user.id},include:{server:{include:{channels:true,members:{include:{user:{select:{id:true,username:true,status:true}}}},roles:true}}}});
  res.json(memberships.map(m => ({...m.server, members:m.server.members.map(x=>({...x.user,roleName:x.roleName}))})));
});
app.post('/api/servers', auth, async (req,res) => {
  const name = String(req.body.name || '').trim().slice(0,48);
  if (!name) return res.status(400).json({error:'Server name required'});
  const created = await prisma.server.create({data:{name,ownerId:req.user.id,channels:{create:[{name:'general',type:'text'},{name:'voice-lounge',type:'voice'}]},roles:{create:[{name:'Admin',color:'#e6b85c',permissions:'*'},{name:'Member',color:'#aab2c0',permissions:'read,send,connect'}]},members:{create:{userId:req.user.id,roleName:'Admin'} }},include:{channels:true,members:{include:{user:{select:{id:true,username:true,status:true}}}},roles:true}});
  res.json({...created,members:created.members.map(x=>({...x.user,roleName:x.roleName}))});
});
app.post('/api/servers/:id/channels', auth, async (req,res) => {
  const member = await prisma.membership.findUnique({where:{userId_serverId:{userId:req.user.id,serverId:req.params.id}}});
  if (!member || member.roleName !== 'Admin') return res.status(403).json({error:'Only server admins can create channels'});
  const name = String(req.body.name || '').trim().toLowerCase().replace(/[^a-z0-9-]/g,'-').slice(0,40);
  const type = req.body.type === 'voice' ? 'voice' : 'text';
  if (!name) return res.status(400).json({error:'Channel name required'});
  const channel = await prisma.channel.create({data:{name,type,serverId:req.params.id}});
  res.json(channel);
});
app.post('/api/servers/:id/join', auth, async (req,res) => {
  try {
    await prisma.membership.create({data:{userId:req.user.id,serverId:req.params.id,roleName:'Member'}});
    res.json({ok:true});
  } catch { res.status(409).json({error:'Already a member or server does not exist.'}); }
});
app.get('/api/channels/:id/messages', auth, async (req,res) => {
  const channel = await prisma.channel.findUnique({where:{id:req.params.id},include:{server:{include:{members:true}}}});
  if (!channel || !channel.server.members.some(m=>m.userId===req.user.id)) return res.status(403).json({error:'No access to channel'});
  const messages = await prisma.message.findMany({where:{channelId:channel.id},include:{user:{select:{id:true,username:true,avatar:true}}},orderBy:{createdAt:'asc'},take:100});
  res.json(messages);
});
app.get('/api/roles/:serverId', auth, async (req,res) => {
  const member = await prisma.membership.findUnique({where:{userId_serverId:{userId:req.user.id,serverId:req.params.serverId}}});
  if (!member) return res.status(403).json({error:'No access'});
  res.json(await prisma.role.findMany({where:{serverId:req.params.serverId}}));
});
app.post('/api/dm', auth, async (req,res) => {
  const receiverId = String(req.body.receiverId || '');
  const content = String(req.body.content || '').trim().slice(0,4000);
  if (!content || receiverId === req.user.id) return res.status(400).json({error:'Invalid message'});
  const message = await prisma.directMessage.create({data:{senderId:req.user.id,receiverId,content},include:{sender:{select:{id:true,username:true}},receiver:{select:{id:true,username:true}}}});
  io.to(`user:${receiverId}`).emit('dm:new',message);
  io.to(`user:${req.user.id}`).emit('dm:new',message);
  res.json(message);
});
app.get('/api/dm/:userId', auth, async (req,res) => {
  const messages = await prisma.directMessage.findMany({where:{OR:[{senderId:req.user.id,receiverId:req.params.userId},{senderId:req.params.userId,receiverId:req.user.id}]},include:{sender:{select:{id:true,username:true}}},orderBy:{createdAt:'asc'},take:200});
  res.json(messages);
});

io.use((socket,next)=>{
  try { socket.user = jwt.verify(socket.handshake.auth?.token, JWT_SECRET || 'dev-only-change-me'); next(); }
  catch { next(new Error('Unauthorized')); }
});
io.on('connection', socket => {
  socket.join(`user:${socket.user.id}`);
  socket.on('channel:join', async ({channelId}) => {
    const channel = await prisma.channel.findUnique({where:{id:channelId},include:{server:{include:{members:true}}}});
    if (channel?.server.members.some(m=>m.userId===socket.user.id)) socket.join(`channel:${channelId}`);
  });
  socket.on('message:send', async ({channelId,content}) => {
    const text = String(content || '').trim().slice(0,4000);
    if (!text || !channelId) return;
    const channel = await prisma.channel.findUnique({where:{id:channelId},include:{server:{include:{members:true}}}});
    if (!channel || !channel.server.members.some(m=>m.userId===socket.user.id)) return;
    const message = await prisma.message.create({data:{channelId,content:text,userId:socket.user.id},include:{user:{select:{id:true,username:true,avatar:true}}}});
    io.to(`channel:${channelId}`).emit('message:new',message);
  });
  socket.on('call:join', ({roomId}) => { if (typeof roomId === 'string' && roomId.length < 160) { socket.join(`call:${roomId}`); socket.to(`call:${roomId}`).emit('call:peer-joined',{peerId:socket.id,userId:socket.user.id}); } });
  socket.on('call:leave', ({roomId}) => { socket.to(`call:${roomId}`).emit('call:peer-left',{peerId:socket.id}); socket.leave(`call:${roomId}`); });
  socket.on('call:signal', ({roomId,targetId,signal}) => { if (typeof targetId==='string' && targetId.length<100) io.to(targetId).emit('call:signal',{from:socket.id,signal,roomId}); });
  socket.on('disconnect',()=>{});
});
const port = Number(process.env.PORT || 4000);
server.listen(port,()=>console.log(`Nebula API listening on :${port}`));
