# Nebula Chat

Responsive community messenger starter inspired by common gaming/community chat layouts. It uses original branding and assets.

## Included
- React + Vite responsive client (desktop sidebar + mobile navigation)
- Express API, JWT auth, Prisma + SQLite database
- Socket.IO realtime messaging and WebRTC signaling for voice/video calls
- Servers, channels, role/permission data model, DMs, member list
- Basic server/channel creation and message history

## Requirements
- Node.js 20+
- npm
- For calls across different networks, configure a TURN server. STUN-only works for many but not all network combinations.

## Run locally
1. Copy `.env.example` to `.env` in `server/` and set `JWT_SECRET` to a long random value.
2. Start backend:
   ```bash
   cd server
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   npm run dev
   ```
3. In another terminal start frontend:
   ```bash
   cd client
   npm install
   npm run dev
   ```
4. Open the Vite URL (usually http://localhost:5173). Register a user, create a server and channels.

## Notes before public deployment
This is a runnable MVP scaffold, not a hardened production service. Add email verification/password reset, rate limiting, abuse reporting, moderation/audit logs, object storage for uploads, backups, TLS, TURN, observability, and security review before exposing it publicly. SQLite is convenient for local development; use PostgreSQL for a multi-instance deployment. Set `CLIENT_ORIGIN` and `VITE_API_URL` for your deployment.
